### v0.1.6

* #19 Improve error messages

### v0.1.5

* #11 Barcode locations

### v0.1.4

* #9 Python 3.6

### v0.1.3

* #7 Support older numpy

### v0.1.2

* #5 Better handling of DLLs

### v0.1.1

* #3 Error when decoding ndarray on an image with a single channel

### v0.1.0

* Initial release
